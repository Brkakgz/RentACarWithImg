package com.rentacar6.rentacar6.config;

import com.rentacar6.rentacar6.model.Admin;
import com.rentacar6.rentacar6.model.Car;
import com.rentacar6.rentacar6.model.Customer;
import com.rentacar6.rentacar6.repository.AdminRepository;
import com.rentacar6.rentacar6.repository.CarRepository;
import com.rentacar6.rentacar6.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final Random random = new Random();

    @Override
    public void run(String... args) throws Exception {
        // Admin Kullanıcı
        Admin admin = new Admin(
                "Admin",
                "Admin",
                generateRandomEmail("admin"),
                generateRandomPhone(),
                "AdminStreet123",
                generateRandomTcNo(),
                passwordEncoder.encode("admin123")
        );
        adminRepository.save(admin);

        // Kullanıcı
        Customer user = new Customer(
                "John",
                "Doe",
                generateRandomEmail("user"),
                generateRandomPhone(),
                "456 User St",
                generateRandomTcNo(),
                passwordEncoder.encode("user123")
        );
        customerRepository.save(user);

        // Araçlar
        Car car1 = new Car("Toyota", "Corolla", 2020, "Red", 50.0, true, "/uploads/cars/Toyota-Corolla-2020-White.jpg");
        Car car2 = new Car("Honda", "Civic", 2019, "Blue", 45.0, true, "/uploads/cars/Honda-Civic-2019-Black.jpg");
        Car car3 = new Car("Ford", "Focus", 2021, "Black", 60.0, true, "/uploads/cars/Ford-Focus-2021-Black.jpg");
        carRepository.save(car1);
        carRepository.save(car2);
        carRepository.save(car3);

        System.out.println("Data loaded successfully!");
    }

    // Benzersiz T.C. Kimlik Numarası Oluşturucu
    private String generateRandomTcNo() {
        StringBuilder tcNo = new StringBuilder();
        tcNo.append(random.nextInt(9) + 1); // 1-9 arasında bir sayı

        for (int i = 1; i < 10; i++) {
            tcNo.append(random.nextInt(10));
        }

        tcNo.append(random.nextInt(5) * 2); // 0, 2, 4, 6, 8
        return tcNo.toString();
    }

    // Benzersiz Telefon Numarası Oluşturucu
    private String generateRandomPhone() {
        StringBuilder phone = new StringBuilder("5");
        for (int i = 0; i < 9; i++) {
            phone.append(random.nextInt(10));
        }
        return phone.toString();
    }

    // Benzersiz E-posta Adresi Oluşturucu
    private String generateRandomEmail(String baseName) {
        int randomNumber = random.nextInt(10000);
        return baseName + "+" + randomNumber + "@example.com";
    }
}
