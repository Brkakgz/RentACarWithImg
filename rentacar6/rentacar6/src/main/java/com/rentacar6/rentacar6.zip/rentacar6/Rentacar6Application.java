package com.rentacar6.rentacar6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rentacar6Application {

	public static void main(String[] args) {
		SpringApplication.run(Rentacar6Application.class, args);
	}

}
